// Stadium Swap for Madden Team Builder
// Derived from Team Builder Unleashed, Copyright (C) 2026 TeamCrafters (GPL-3.0-or-later).
// Modified for Madden NFL Team Builder. See LICENSE and NOTICE.md.
//
// ISOLATED world: the page-world script cannot read chrome.storage, so it asks us over
// a DOM event and we answer with the armed stadium (or null).
(function () {
  const KEY = 'msStadium';
  window.addEventListener('ms-stadium-request', () => {
    chrome.storage.local.get(KEY, (stored) => {
      const value = stored && stored[KEY] ? stored[KEY] : null;
      window.dispatchEvent(new CustomEvent('ms-stadium-response', { detail: JSON.stringify(value) }));
    });
  });

  // Capture store (diagnostics): keeps the newest requests, under ~6 MB total.
  const CAP = 'msCapture';
  let chain = Promise.resolve();
  window.addEventListener('ms-capture', (e) => {
    let entry;
    try { entry = JSON.parse(e.detail); } catch { return; }
    chain = chain.then(() => new Promise((resolve) => {
      try {
        chrome.storage.local.get(CAP, (stored) => {
          const arr = Array.isArray(stored && stored[CAP]) ? stored[CAP] : [];
          arr.push(entry);
          let total = 0; const keep = [];
          for (let i = arr.length - 1; i >= 0 && keep.length < 80; i--) {
            const n = JSON.stringify(arr[i]).length;
            if (total + n > 6e6) break;
            total += n; keep.unshift(arr[i]);
          }
          chrome.storage.local.set({ [CAP]: keep }, resolve);
        });
      } catch { resolve(); }
    })).catch(() => {});
  });
})();

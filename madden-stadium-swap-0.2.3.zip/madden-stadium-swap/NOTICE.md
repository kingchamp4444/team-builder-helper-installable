# Notice

Stadium Swap for Madden Team Builder is derived from **Team Builder Unleashed**
(Copyright (C) 2026 TeamCrafters), licensed under the GNU General Public License v3.0 or later.
This derivative is released under the same license; see LICENSE.

Changes: reduced to the stadium feature only; retargeted to EA's Madden NFL Team Builder;
rewritten popup, bridge and save-time patch. `stadiums.json` is taken from the original's
`reference/stadiums.json`.

Unofficial. Not affiliated with or endorsed by Electronic Arts Inc. or TeamCrafters.
EA, EA SPORTS and Madden NFL are trademarks of Electronic Arts Inc.

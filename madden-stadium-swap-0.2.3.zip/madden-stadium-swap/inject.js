// Stadium Swap for Madden Team Builder
// Derived from Team Builder Unleashed, Copyright (C) 2026 TeamCrafters (GPL-3.0-or-later).
// Modified for Madden NFL Team Builder. See LICENSE and NOTICE.md.
//
// MAIN world. Team Builder saves by PUTting the team payload to a pre-signed S3 URL. If a
// stadium is armed we hold that one request, show a confirmation, and only after you click
// "Apply stadium" do we change two fields in the JSON. On ANY problem the original request
// goes out untouched. With nothing armed, nothing is touched at all.
(function () {
  if (window.__msStadiumSwapInstalled) return;
  window.__msStadiumSwapInstalled = true;

  const nativeFetch = window.fetch.bind(window);
  const XHR = window.XMLHttpRequest;
  const origOpen = XHR.prototype.open;
  const origSend = XHR.prototype.send;

  // Madden's upload host/path are not confirmed yet, so match any S3 PUT and gate on the
  // payload shape instead (must contain teamData.teamInfos and the stadium recipe).
  function isUpload(url, method) {
    try {
      const u = new URL(url, location.href);
      return String(method).toUpperCase() === 'PUT' && /(^|\.)amazonaws\.com$/.test(u.hostname);
    } catch { return false; }
  }

  function getArmedStadium() {
    return new Promise((resolve) => {
      const timer = setTimeout(() => { cleanup(); resolve(null); }, 1500);
      function onResponse(e) {
        cleanup();
        try { resolve(JSON.parse(e.detail)); } catch { resolve(null); }
      }
      function cleanup() {
        clearTimeout(timer);
        window.removeEventListener('ms-stadium-response', onResponse);
      }
      window.addEventListener('ms-stadium-response', onResponse);
      window.dispatchEvent(new CustomEvent('ms-stadium-request'));
    });
  }

  function isObj(v) { return v && typeof v === 'object' && !Array.isArray(v); }

  // Throws with a plain-language reason if the payload doesn't look like what we expect.
  function applyStadium(text, stadium) {
    const id = Number.isInteger(stadium && stadium.stadiumId) ? String(stadium.stadiumId) : '';
    if (!id) throw new Error('The armed stadium has no valid ID.');
    const payload = JSON.parse(text);
    const teamInfos = payload && payload.teamData && payload.teamData.teamInfos;
    if (!isObj(teamInfos)) throw new Error('Could not find teamData.teamInfos in this save.');
    const recipe = payload.teamData.frostbiteData && payload.teamData.frostbiteData.stadiumRecipe;
    if (!isObj(recipe)) throw new Error('Could not find teamData.frostbiteData.stadiumRecipe in this save.');
    const before = teamInfos.STADIUM_ID === undefined ? '(not set)' : String(teamInfos.STADIUM_ID);
    teamInfos.STADIUM_ID = id;
    recipe.assetName = id + '_stadium_recipe';
    return { text: JSON.stringify(payload), before, id };
  }

  function confirmDialog(stadium, info, errorMessage) {
    return new Promise((resolve) => {
      const host = document.createElement('div');
      host.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;font:14px system-ui,sans-serif;';
      const box = document.createElement('div');
      box.setAttribute('role', 'dialog');
      box.setAttribute('aria-modal', 'true');
      box.style.cssText = 'background:#fff;color:#111;max-width:440px;margin:16px;padding:20px;border-radius:10px;box-shadow:0 10px 40px rgba(0,0,0,.5);';
      const h = document.createElement('h2');
      h.style.cssText = 'margin:0 0 10px;font-size:18px;';
      h.textContent = errorMessage ? 'Stadium could not be applied' : 'Apply this stadium before saving?';
      const p = document.createElement('p');
      p.style.cssText = 'margin:0 0 16px;line-height:1.4;';
      const name = (stadium && typeof stadium.displayName === 'string' && stadium.displayName.trim()) || 'Selected stadium';
      p.textContent = errorMessage
        ? errorMessage + ' Your save will go through unchanged.'
        : name + ' will change STADIUM_ID from "' + info.before + '" to "' + info.id + '" in this save request.';
      const row = document.createElement('div');
      row.style.cssText = 'display:flex;gap:8px;justify-content:flex-end;';
      const mk = (label, primary, value) => {
        const b = document.createElement('button');
        b.textContent = label;
        b.style.cssText = 'padding:8px 14px;border-radius:6px;border:1px solid #888;cursor:pointer;font:inherit;' +
          (primary ? 'background:#0a6;color:#fff;border-color:#0a6;' : 'background:#eee;color:#111;');
        b.addEventListener('click', () => { host.remove(); resolve(value); });
        return b;
      };
      if (errorMessage) {
        row.append(mk('Save unchanged', true, false));
      } else {
        row.append(mk('Save without changes', false, false), mk('Yes, apply stadium', true, true));
      }
      box.append(h, p, row);
      host.append(box);
      (document.body || document.documentElement).append(host);
    });
  }

  // Returns the text to send, or null to send the original.
  async function chooseBody(originalText) {
    if (typeof originalText !== 'string') return null;
    const stadium = await getArmedStadium();
    if (!stadium || !Number.isInteger(stadium.stadiumId)) return null;
    let result = null, error = '';
    try { result = applyStadium(originalText, stadium); }
    catch (err) { error = err.message || String(err); console.warn('[Stadium Swap]', error); }
    const ok = await confirmDialog(stadium, result, error);
    return ok && result ? result.text : null;
  }

  async function bodyToText(body) {
    if (typeof body === 'string') return body;
    if (body instanceof Blob) return body.text();
    if (body instanceof ArrayBuffer) return new TextDecoder().decode(body);
    if (ArrayBuffer.isView(body)) return new TextDecoder().decode(body);
    return null;
  }

  function textToOriginalType(text, original) {
    if (original instanceof Blob) return new Blob([text], { type: original.type });
    if (original instanceof ArrayBuffer) return new TextEncoder().encode(text).buffer;
    if (ArrayBuffer.isView(original)) return new TextEncoder().encode(text);
    return text;
  }

  // Diagnostics: never log the query string, it carries the pre-signed credentials.
  function logSeen(url) {
    try { const u = new URL(url, location.href); console.info('[Stadium Swap] saw upload PUT:', u.hostname + u.pathname); } catch {}
  }


  // ---- Capture (diagnostics only): records request shapes so the real stadium field can be found.
  // Nothing is sent anywhere; it stays in this browser until you download it from the popup.
  const REDACT = /token|auth|secret|passw|email|cookie|session|nucleus|persona|userid|user_id|accountid|account_id|signature|credential/i;
  function redact(v, depth) {
    if (depth > 12) return '[deep]';
    if (Array.isArray(v)) return v.map((x) => redact(x, depth + 1));
    if (v && typeof v === 'object') {
      const out = {};
      for (const k of Object.keys(v)) out[k] = (REDACT.test(k) || /^(pid|uid)$/i.test(k)) ? '[redacted]' : redact(v[k], depth + 1);
      return out;
    }
    return v;
  }
  function hostPath(url) {
    try { const u = new URL(url, location.href); return u.hostname + u.pathname; } catch { return '(unparseable)'; }
  }
  function recordRequest(method, url, bodyText) {
    try {
      const m = String(method || 'GET').toUpperCase();
      const where = hostPath(url);
      if ((m === 'GET' || m === 'HEAD') && !/\.json$|api|stadium|team|roster/i.test(where)) return;
      const entry = { t: new Date().toISOString(), method: m, where: where };
      if (m !== 'GET' && m !== 'HEAD' && typeof bodyText === 'string') {
        entry.bytes = bodyText.length;
        try { entry.body = redact(JSON.parse(bodyText), 0); } catch { entry.body = '(not JSON)'; }
      }
      window.dispatchEvent(new CustomEvent('ms-capture', { detail: JSON.stringify(entry) }));
    } catch {}
  }

  // Records a response only if it is JSON-ish, under ~600 KB, and mentions "stadium" (to find the stadium catalog).
  const WANTED = /stadium_list/i; // the site's own stadium catalog
  // Shrinks big lists to their simple fields (ids, names, numbers) so they fit in storage.
  function compact(v, d) {
    if (Array.isArray(v)) return v.map((x) => (x && typeof x === 'object') ? compact(x, d + 1) : x);
    if (v && typeof v === 'object') {
      const o = {};
      for (const k of Object.keys(v)) {
        const x = v[k];
        if (x && typeof x === 'object') o[k] = d >= 2 ? (Array.isArray(x) ? '[arr ' + x.length + ']' : '[obj]') : compact(x, d + 1);
        else o[k] = (typeof x === 'string' && x.length > 80) ? x.slice(0, 80) + '...' : x;
      }
      return o;
    }
    return v;
  }
  function recordResponse(method, url, text, force, meta) {
    try {
      const base = { t: new Date().toISOString(), method: String(method).toUpperCase(), where: hostPath(url) };
      if (force) {
        const entry = Object.assign(base, { kind: 'stadium_list', meta: meta || {}, bytes: typeof text === 'string' ? text.length : -1 });
        if (typeof text === 'string' && text.length <= 20000000) {
          let parsed = null;
          try { parsed = JSON.parse(text.trim()); } catch {}
          if (parsed !== null) entry.response = compact(redact(parsed, 0), 0);
          else entry.responseText = text.trim().slice(0, 2000);
        }
        window.dispatchEvent(new CustomEvent('ms-capture', { detail: JSON.stringify(entry) }));
        return;
      }
      if (typeof text !== 'string' || text.length > 600000 || !/stadium/i.test(text)) return;
      const trimmed = text.trim();
      if (trimmed[0] !== '{' && trimmed[0] !== '[') return;
      let parsed; try { parsed = JSON.parse(trimmed); } catch { return; }
      base.response = redact(parsed, 0);
      window.dispatchEvent(new CustomEvent('ms-capture', { detail: JSON.stringify(base) }));
    } catch (err) {
      try { window.dispatchEvent(new CustomEvent('ms-capture', { detail: JSON.stringify({ t: new Date().toISOString(), method: 'NOTE', where: hostPath(url), error: String(err && err.message || err) }) })); } catch {}
    }
  }
  function watchResponse(promise, method, url) {
    const force = WANTED.test(url);
    promise.then((res) => {
      try {
        const ct = (res.headers && res.headers.get('content-type')) || '';
        if (!force && !/json|text/i.test(ct)) return;
        const meta = { via: 'fetch', status: res.status, contentType: ct };
        res.clone().text().then((t) => recordResponse(method, url, t, force, meta))
          .catch((err) => { if (force) recordResponse(method, url, null, true, Object.assign(meta, { error: String(err && err.message || err) })); });
      } catch {}
    }).catch((err) => { if (force) recordResponse(method, url, null, true, { via: 'fetch', error: 'request failed: ' + String(err && err.message || err) }); });
  }
  function captureFetch(input, init, method, url) {
    try {
      const m = String(method).toUpperCase();
      const b = init && init.body;
      if (m === 'GET' || m === 'HEAD') recordRequest(m, url, null);
      else if (typeof b === 'string') recordRequest(m, url, b);
      else if (b instanceof Blob) b.text().then((t) => recordRequest(m, url, t)).catch(() => {});
      else if (b instanceof ArrayBuffer || ArrayBuffer.isView(b)) recordRequest(m, url, new TextDecoder().decode(b));
      else if (!b && input instanceof Request) input.clone().text().then((t) => recordRequest(m, url, t)).catch(() => recordRequest(m, url, null));
      else recordRequest(m, url, null);
    } catch {}
  }

  window.fetch = async function (input, init) {
    const method = (init && init.method) || (input instanceof Request ? input.method : 'GET');
    const url = input instanceof Request ? input.url : String(input);
    captureFetch(input, init, method, url);
    if (!isUpload(url, method)) { const p = nativeFetch(input, init); watchResponse(p, method, url); return p; }
    try {
      logSeen(url);
      const hasInit = init && Object.prototype.hasOwnProperty.call(init, 'body');
      const original = hasInit ? init.body : (input instanceof Request ? await input.clone().blob() : null);
      const text = original == null ? null : await bodyToText(original);
      const chosen = text === null ? null : await chooseBody(text);
      if (chosen === null) return nativeFetch(input, init);
      return nativeFetch(input, Object.assign({}, init, { body: textToOriginalType(chosen, original) }));
    } catch (err) {
      console.error('[Stadium Swap] save update failed, saving unchanged:', err);
      return nativeFetch(input, init);
    }
  };

  XHR.prototype.open = function (method, url) {
    this.__msInfo = { method: method, url: String(url) };
    return origOpen.apply(this, arguments);
  };

  XHR.prototype.send = function (body) {
    const info = this.__msInfo;
    if (info) {
      try {
        this.addEventListener('loadend', async () => {
          const force = WANTED.test(info.url);
          try {
            const rt = this.responseType;
            let text = null;
            if (rt === '' || rt === 'text') text = this.responseText;
            else if (rt === 'json') text = JSON.stringify(this.response);
            else if (rt === 'arraybuffer' && this.response) text = new TextDecoder().decode(this.response);
            else if (rt === 'blob' && this.response) text = await this.response.text();
            recordResponse(info.method, info.url, text, force, { via: 'xhr', status: this.status, responseType: rt, contentType: this.getResponseHeader('content-type') || '' });
          } catch (err) {
            if (force) recordResponse(info.method, info.url, null, true, { via: 'xhr', error: String(err && err.message || err) });
          }
        });
      } catch {}
      try { bodyToText(body).then((t) => recordRequest(info.method, info.url, t)).catch(() => recordRequest(info.method, info.url, null)); } catch {}
    }
    if (!info || !isUpload(info.url, info.method)) return origSend.call(this, body);
    logSeen(info.url);
    bodyToText(body)
      .then((text) => (text === null ? null : chooseBody(text)))
      .then((chosen) => origSend.call(this, chosen === null ? body : textToOriginalType(chosen, body)))
      .catch((err) => {
        console.error('[Stadium Swap] save update failed, saving unchanged:', err);
        origSend.call(this, body);
      });
  };
})();

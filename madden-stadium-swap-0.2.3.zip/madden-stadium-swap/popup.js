// Stadium Swap for Madden Team Builder
// Derived from Team Builder Unleashed, Copyright (C) 2026 TeamCrafters (GPL-3.0-or-later).
(async function () {
  const KEY = 'msStadium';
  const list = document.getElementById('list');
  const filter = document.getElementById('filter');
  const status = document.getElementById('status');
  const stadiums = await (await fetch(chrome.runtime.getURL('stadiums.json'))).json();

  function render() {
    const q = filter.value.trim().toLowerCase();
    list.replaceChildren(...stadiums
      .filter((s) => !q || s.displayName.toLowerCase().includes(q))
      .map((s) => { const o = document.createElement('option'); o.value = s.id; o.textContent = s.displayName; return o; }));
  }

  function renderStatus(stored) {
    const v = stored[KEY];
    const armed = v && Number.isInteger(v.stadiumId);
    status.textContent = armed ? 'Armed: ' + v.displayName + ' (ID ' + v.stadiumId + ')' : 'Nothing armed.';
    status.classList.toggle('armed', !!armed);
  }

  document.getElementById('arm').addEventListener('click', () => {
    const id = Number(list.value);
    const s = stadiums.find((x) => x.id === id);
    if (!s) return;
    chrome.storage.local.set({ [KEY]: { stadiumId: s.id, displayName: s.displayName } });
  });
  document.getElementById('clear').addEventListener('click', () => chrome.storage.local.remove(KEY));
  filter.addEventListener('input', render);
  const capStatus = document.getElementById('capstatus');
  function renderCap() {
    chrome.storage.local.get('msCapture', (s) => {
      const n = Array.isArray(s && s.msCapture) ? s.msCapture.length : 0;
      capStatus.textContent = n ? n + ' requests captured.' : 'Nothing captured.';
    });
  }
  document.getElementById('dl').addEventListener('click', () => {
    chrome.storage.local.get('msCapture', (s) => {
      const data = { version: chrome.runtime.getManifest().version, requests: (s && s.msCapture) || [] };
      const blob = new Blob([JSON.stringify(data, null, 1)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'stadium-swap-capture.json';
      document.body.append(a); a.click(); a.remove();
    });
  });
  document.getElementById('capclear').addEventListener('click', () => chrome.storage.local.remove('msCapture'));
  chrome.storage.onChanged.addListener(() => { chrome.storage.local.get(KEY, renderStatus); renderCap(); });

  render();
  renderCap();
  chrome.storage.local.get(KEY, renderStatus);
})();

# Stadium Swap for Madden Team Builder (unofficial)

1. Chrome → `chrome://extensions` → Developer mode → **Load unpacked** → pick this folder.
2. Click the extension icon, choose a stadium, press **Arm stadium**.
3. Open https://www.ea.com/games/madden-nfl/team-builder, build your team, press **Save**.
4. A dialog asks whether to apply the stadium. Nothing changes unless you click **Yes**.

## Status: untested against Madden
The CFB version patches `teamData.teamInfos.STADIUM_ID` and
`teamData.frostbiteData.stadiumRecipe.assetName` in the S3 save request. Madden's payload is
assumed to match. If it doesn't, the dialog says which field was missing and the save goes
through unchanged. Open DevTools → Console and look for `[Stadium Swap] saw upload PUT:` to
confirm the save request is being detected (only host and path are logged, never the signed query).
